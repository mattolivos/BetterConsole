	var BottomDropDownMenuItems = document.createElement('style')
	BottomDropDownMenuItems.innerHTML = ".dropup .dropdown-submenu>.dropdown-menu { top: 0; bottom: auto;}";
	document.body.appendChild(BottomDropDownMenuItems);
	
	var TopDropDownMenuItems = document.createElement('style');
	TopDropDownMenuItems.innerHTML = ".dropdown-menu .dropdown-submenu:nth-last-child(-n + 12) > ul { top: auto; bottom: 0; }";
	document.body.appendChild(TopDropDownMenuItems);
	
	var DropDownMenu = document.createElement('style');
	DropDownMenu.innerHTML = ".btn-group.dropup.open > .dropdown-menu { bottom:-120% !important; left: 100% !important; }";
	document.body.appendChild(DropDownMenu);
	
		
	var WeirdTabOnLeft = document.createElement('style');
	WeirdTabOnLeft.innerHTML = ".visible-desktop.roster-container{ display:none !important}";
	document.body.appendChild(WeirdTabOnLeft);
